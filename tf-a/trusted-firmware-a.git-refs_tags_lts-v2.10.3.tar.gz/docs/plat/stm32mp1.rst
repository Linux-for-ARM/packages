:orphan:

STMicroelectronics STM32MP1 (old page)
======================================

Please check :ref:`STM32 MPUs` page for generic information about
STMicroelectronics STM32 microprocessors in TF-A, and :ref:`STM32MP1` page
for specificities on STM32MP1x platforms.

*Copyright (c) 2018-2023, STMicroelectronics - All Rights Reserved*
