/*
 * Copyright © 2020-2022 The Crust Firmware Authors.
 * SPDX-License-Identifier: BSD-3-Clause OR GPL-2.0-only
 */

#include <dram.h>

void WEAK
dram_suspend(void)
{
}

void WEAK
dram_resume(void)
{
}

void WEAK
dram_init(void)
{
}
